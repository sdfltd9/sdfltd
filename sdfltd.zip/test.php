



<?php 
phpinfo();
?>
