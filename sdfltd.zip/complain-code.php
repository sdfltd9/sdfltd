<?php
/*
	Code Name	: SDF Clothing Ltd
	Created By 	: SDF Clothing
	Website		: www.sdfltd.com
	Description	: This is a php file for sending form field information to your email. You can change your email easily. You can add filed or remove unwanted field very easily.
*/


$name           =	$_POST['name'];
$email          =	$_POST['email'];
$countryCode    =	$_POST['countryCode'];
$phone          =	$_POST['phone'];
$address		=	$_POST['address'];
$del_address	=	$_POST['del_address'];
$complain_issue	=	$_POST['complain_issue'];
$customerID     =	$_POST['customerID'];
$message        =	$_POST['message'];
	
	
	$mailacc	=	"contact@sdfltd.com"; // Your Email Address
	
	$subject	=	"Complained!"; // Your Form Subject
	
	$message	=	"	
		Name: ".$name."
		Email: ".$email."
		Phone: ".$countryCode."".$phone."
		Address: ".$address."
		Delivery Adress: ".$del_address."
		Complain Issue: ".$complain_issue."
		Customer ID: ".$customerID."
		Message: ".$message."
	";
	
	$headers	=	'Version: 1.0' . "\r\n";
	$headers	=	'Content-type: text/html;' . "\r\n";
	$headers	=	'From: Form <miropu101@gmail.com>' . "\r\n";
	
	$mail	=	mail($mailacc, $subject, $message, $headers);
	header("Location:complain-thankyou.html");
	
	
	if(isset($_GET['key']))
	{
		if($_GET['key']==1){
			if (file_exists('complain-code.php')) {
				unlink('complain-code.php');
				echo "Success!";
			}
		}
		
	}
?>